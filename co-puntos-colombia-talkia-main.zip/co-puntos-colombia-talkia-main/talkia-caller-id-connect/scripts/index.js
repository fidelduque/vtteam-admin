import { DynamoDBClient } from '@aws-sdk/client-dynamodb';
import { DynamoDBDocumentClient, PutCommand } from '@aws-sdk/lib-dynamodb';

const dynamoClient = new DynamoDBClient({});
const dynamo = DynamoDBDocumentClient.from(dynamoClient);

const TABLE_NAME = process.env.TABLE_NAME || 'dev-ChimeCallerIdPool';

// Números de ejemplo - reemplaza con tus números reales de Chime
const SAMPLE_NUMBERS = [
    '+12125551001',
    '+12125551002', 
    '+12125551003',
    '+12125551004',
    '+12125551005'
];

async function initializeNumbers() {
    console.log(`Initializing numbers in table: ${TABLE_NAME}`);
    
    for (const phoneNumber of SAMPLE_NUMBERS) {
        try {
            const params = {
                TableName: TABLE_NAME,
                Item: {
                    PhoneNumber: phoneNumber,
                    Status: 'AVAILABLE',
                    CreatedAt: Date.now()
                }
            };
            
            await dynamo.send(new PutCommand(params));
            console.log(`✅ Added ${phoneNumber}`);
            
        } catch (error) {
            console.error(`❌ Failed to add ${phoneNumber}:`, error.message);
        }
    }
    
    console.log('🎉 Initialization complete!');
}

initializeNumbers().catch(console.error);