import { DynamoDBClient } from '@aws-sdk/client-dynamodb';
import { DynamoDBDocumentClient, GetCommand, UpdateCommand } from '@aws-sdk/lib-dynamodb';

const dynamoClient = new DynamoDBClient({});
const dynamo = DynamoDBDocumentClient.from(dynamoClient);

const CALLER_ID_MAPPING_TABLE = process.env.CALLER_ID_MAPPING_TABLE;
const CALLER_ID_POOL_TABLE = process.env.CALLER_ID_POOL_TABLE;

const releaseNumber = async (phoneNumber) => {
    try {
        const params = {
            TableName: CALLER_ID_POOL_TABLE,
            Key: { PhoneNumber: phoneNumber },
            UpdateExpression: 'SET isAvailable = :available REMOVE TransactionId, ReservedAt',
            ExpressionAttributeValues: { ':available': 'true' }
        };

        await dynamo.send(new UpdateCommand(params));
        console.log(`Released number: ${phoneNumber}`);
    } catch (error) {
        console.error(`Failed to release number ${phoneNumber}:`, error);
        throw error;
    }
};

export const handler = async (event) => {
    try {
        // Get the caller ID from the event
        const { callerId } = event.Details.Parameters;
        
        if (!callerId) {
            return {
                statusCode: 400,
                error: 'Missing callerId parameter'
            };
        }

        // Query the mapping table
        const params = {
            TableName: CALLER_ID_MAPPING_TABLE,
            Key: {
                ChimeCallerId: callerId
            }
        };

        const result = await dynamo.send(new GetCommand(params));
        
        if (!result.Item) {
            return {
                statusCode: 404,
                error: 'No mapping found for the provided caller ID'
            };
        }

        // Release the number back to the pool
        await releaseNumber(callerId);

        return {
            statusCode: 200,
            originalCallerId: result.Item.OriginalCallerId,
            transactionId: result.Item.TransactionId,
            createdAt: result.Item.CreatedAt
        };

    } catch (error) {
        console.error('Error retrieving original number:', error);
        return {
            statusCode: 500,
            error: 'Internal server error'
        };
    }
}; 