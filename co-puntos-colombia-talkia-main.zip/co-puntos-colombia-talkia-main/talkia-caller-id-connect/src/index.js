import { DynamoDBClient } from '@aws-sdk/client-dynamodb';
import { DynamoDBDocumentClient, UpdateCommand, PutCommand, QueryCommand } from '@aws-sdk/lib-dynamodb';

const dynamoClient = new DynamoDBClient({});
const dynamo = DynamoDBDocumentClient.from(dynamoClient);

const CALLER_ID_POOL_TABLE = process.env.CALLER_ID_POOL_TABLE;
const CALLER_ID_MAPPING_TABLE = process.env.CALLER_ID_MAPPING_TABLE;
const AMAZON_CONNECT_PHONE_NUMBER = process.env.AMAZON_CONNECT_PHONE_NUMBER;

const selectAvailableNumber = async () => {
    const params = {
        TableName: CALLER_ID_POOL_TABLE,
        IndexName: 'IsAvailableIndex',
        KeyConditionExpression: 'isAvailable = :available',
        ExpressionAttributeValues: { ':available': 'true' },
        Limit: 1
    };

    const result = await dynamo.send(new QueryCommand(params));
    console.log('result', result);
    return result.Items?.[0] || null;
};

const lockNumber = async (phoneNumber, transactionId) => {
    const params = {
        TableName: CALLER_ID_POOL_TABLE,
        Key: { PhoneNumber: phoneNumber },
        UpdateExpression: 'SET isAvailable = :inUse, TransactionId = :transactionId, ReservedAt = :timestamp',
        ExpressionAttributeValues: {
            ':inUse': 'false',
            ':transactionId': transactionId,
            ':timestamp': Date.now()
        }
    };

    await dynamo.send(new UpdateCommand(params));
};

// Crear mapeo de caller IDs
const createMapping = async (chimeCallerId, originalCallerId, transactionId) => {
    const params = {
        TableName: CALLER_ID_MAPPING_TABLE,
        Item: {
            ChimeCallerId: chimeCallerId,
            OriginalCallerId: originalCallerId,
            TransactionId: transactionId,
            CreatedAt: Date.now(),
            ExpiresAt: Math.floor(Date.now() / 1000) + (24 * 60 * 60) // 24 horas TTL
        }
    };

    await dynamo.send(new PutCommand(params));
};

const releaseNumber = async (phoneNumber) => {
    try {
        const params = {
            TableName: CALLER_ID_POOL_TABLE,
            Key: { PhoneNumber: phoneNumber },
            UpdateExpression: 'SET isAvailable = :available REMOVE TransactionId, ReservedAt',
            ExpressionAttributeValues: { ':available': 'true' }
        };

        await dynamo.send(new UpdateCommand(params));
        console.log(`Released number: ${phoneNumber}`);
    } catch (error) {
        console.error(`Failed to release number ${phoneNumber}:`, error);
    }
};

const handleNewOutboundCall = async (event) => {
    const originalCallerId = event.CallDetails.Participants[0].SipHeaders['X-Original-Caller-ID'] || event.CallDetails.Participants[0].From;
    const transactionId = event.CallDetails.TransactionId;
    
    console.log(`New outbound call from ${originalCallerId}, transaction: ${transactionId}`);
    
    try {
        // 1. Buscar número disponible
        const availableNumber = await selectAvailableNumber();
        
        if (!availableNumber) {
            console.error('No available numbers in pool');
            return {
                SchemaVersion: '1.0',
                Actions: [{
                    Type: 'Hangup',
                    Parameters: { SipResponseCode: '503' }
                }]
            };
        }
        
        // 2. Reservar número
        await lockNumber(availableNumber.PhoneNumber, transactionId);
        
        // 3. Crear mapeo
        await createMapping(availableNumber.PhoneNumber, originalCallerId, transactionId);
        
        console.log(`Reserved ${availableNumber.PhoneNumber} for ${originalCallerId}`);
        
        // 4. Guardar en transaction attributes
        return {
            SchemaVersion: '1.0',
            Actions: [],
            TransactionAttributes: {
                ProxyCallerId: availableNumber.PhoneNumber,
                OriginalCallerId: originalCallerId,
                ConnectPhoneNumber: AMAZON_CONNECT_PHONE_NUMBER
            }
        };
        
    } catch (error) {
        console.error('Error in NEW_OUTBOUND_CALL:', error);
        return {
            SchemaVersion: '1.0',
            Actions: [{ Type: 'Hangup', Parameters: { SipResponseCode: '500' } }]
        };
    }
};

// Manejar NEW_INBOUND_CALL
const handleNewInboundCall = async (event) => {
    const originalCallerId = event.CallDetails.Participants[0].SipHeaders['X-Original-Caller-ID'] || event.CallDetails.Participants[0].From;
    const destinationNumber = "+18335665716";
    // const destinationNumber = event.CallDetails.Participants[0].To; // +18335665716
    const transactionId = event.CallDetails.TransactionId;
    
    console.log(`New inbound call from ${originalCallerId} to ${destinationNumber}, transaction: ${transactionId}`);
    
    try {
        // 1. Buscar número disponible
        const availableNumber = await selectAvailableNumber();
        
        if (!availableNumber) {
            console.error('No available numbers in pool');
            return {
                SchemaVersion: '1.0',
                Actions: [{
                    Type: 'Hangup',
                    Parameters: { SipResponseCode: '503' }
                }]
            };
        }
        
        // 2. Reservar número
        await lockNumber(availableNumber.PhoneNumber, transactionId);
        
        // 3. Crear mapeo
        await createMapping(availableNumber.PhoneNumber, originalCallerId, transactionId);
        
        console.log(`Processing inbound call: ${originalCallerId} -> ${destinationNumber} via proxy ${availableNumber.PhoneNumber}`);
        
        // 4. Inmediatamente hacer CallAndBridge hacia Amazon Connect
        return {
            SchemaVersion: '1.0',
            Actions: [{
                Type: 'CallAndBridge',
                Parameters: {
                    CallTimeoutSeconds: 30,
                    CallerIdNumber: availableNumber.PhoneNumber,
                    Endpoints: [{
                        BridgeEndpointType: 'PSTN',
                        Uri: destinationNumber // +18335665716
                    }]
                }
            }]
        };
        
    } catch (error) {
        console.error('Error in NEW_INBOUND_CALL:', error);
        return {
            SchemaVersion: '1.0',
            Actions: [{ Type: 'Hangup', Parameters: { SipResponseCode: '500' } }]
        };
    }
};


// Manejar CALL_ANSWERED
const handleCallAnswered = (event) => {
    const transactionAttributes = event.CallDetails.TransactionAttributes;
    
    if (!transactionAttributes?.ProxyCallerId) {
        console.error('Missing transaction attributes');
        return {
            SchemaVersion: '1.0',
            Actions: [{ Type: 'Hangup' }]
        };
    }
    
    console.log(`Call answered, bridging with proxy ${transactionAttributes.ProxyCallerId}`);
    
    return {
        SchemaVersion: '1.0',
        Actions: [{
            Type: 'CallAndBridge',
            Parameters: {
                CallTimeoutSeconds: 30,
                CallerIdNumber: transactionAttributes.ProxyCallerId,
                Endpoints: [{
                    BridgeEndpointType: 'PSTN',
                    Uri: transactionAttributes.ConnectPhoneNumber
                }]
            }
        }]
    };
};

// Manejar HANGUP
const handleHangup = async (event) => {
    const transactionId = event.CallDetails.TransactionId;
    
    // Buscar el número proxy usado
    let proxyCallerId = null;
    
    if (event.CallDetails.TransactionAttributes?.ProxyCallerId) {
        proxyCallerId = event.CallDetails.TransactionAttributes.ProxyCallerId;
    } else {
        // Buscar en participantes
        const outboundParticipant = event.CallDetails.Participants?.find(p => p.Direction === 'Outbound');
        if (outboundParticipant) {
            proxyCallerId = outboundParticipant.From;
        }
    }
    
    if (proxyCallerId) {
        console.log(`Releasing proxy number ${proxyCallerId} for transaction ${transactionId}`);
        await releaseNumber(proxyCallerId);
    } else {
        console.warn(`Could not find proxy caller ID to release for transaction ${transactionId}`);
    }
    
    return { 
        SchemaVersion: '1.0', 
        Actions: [{
            Type: 'Hangup',
            Parameters: {
                SipResponseCode: '200'
            }
        }]
    };
};

// Handler principal
export const handler = async (event) => {
    console.log('SMA Event:', JSON.stringify(event, null, 2));
    
    const { InvocationEventType } = event;
    
    try {
        switch (InvocationEventType) {
            case 'NEW_OUTBOUND_CALL':
                return await handleNewOutboundCall(event);
                
            case 'CALL_ANSWERED':
                return handleCallAnswered(event);
                
            case 'HANGUP':
                return await handleHangup(event);
                
            case 'RINGING':
            case 'ACTION_SUCCESSFUL':
                console.log(`Event: ${InvocationEventType}`);
                return { SchemaVersion: '1.0', Actions: [] };
            case 'NEW_INBOUND_CALL':
                return await handleNewInboundCall(event);
                
            default:
                console.warn(`Unknown event type: ${InvocationEventType}`);
                return { SchemaVersion: '1.0', Actions: [] };
        }
        
    } catch (error) {
        console.error('Handler error:', error);
        return {
            SchemaVersion: '1.0',
            Actions: [{ Type: 'Hangup' }]
        };
    }
};