#!/usr/bin/env python3
"""
Excel to DynamoDB Upload Script
Uploads fraud numbers and blocked numbers data from Excel files to DynamoDB tables.
"""

import boto3
import pandas as pd
import sys
import argparse
from datetime import datetime
from typing import Dict, List, Any
import logging
from botocore.exceptions import ClientError

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

class ExcelToDynamoUploader:
    def __init__(self, environment: str = 'dev', region: str = 'us-east-1', profile: str = None):
        """Initialize the uploader with AWS DynamoDB client."""
        self.environment = environment
        self.region = region
        self.profile = profile
        
        # Create boto3 session with profile if specified
        if profile:
            session = boto3.Session(profile_name=profile)
            self.dynamodb = session.resource('dynamodb', region_name=region)
        else:
            self.dynamodb = boto3.resource('dynamodb', region_name=region)
        
        # Table names based on environment
        self.fraud_table_name = f"talkia-{environment}-fraud"
        self.blocked_table_name = f"talkia-{environment}-blocked"
        
        # Get table references
        try:
            self.fraud_table = self.dynamodb.Table(self.fraud_table_name)
            self.blocked_table = self.dynamodb.Table(self.blocked_table_name)
        except ClientError as e:
            logger.error(f"Error accessing DynamoDB tables: {e}")
            raise

    def read_excel_file(self, file_path: str, sheet_name: str = None) -> pd.DataFrame:
        """Read Excel file and return DataFrame."""
        try:
            if sheet_name:
                df = pd.read_excel(file_path, sheet_name=sheet_name)
            else:
                df = pd.read_excel(file_path)
            
            logger.info(f"Successfully read {len(df)} rows from {file_path}")
            return df
        except Exception as e:
            logger.error(f"Error reading Excel file {file_path}: {e}")
            raise

    def prepare_fraud_item(self, row: Dict[str, Any]) -> Dict[str, Any]:
        """Prepare fraud numbers item for DynamoDB."""
        item = {
            'id_call': str(row['id_call']).strip(),
            'status': str(row.get('status', '')).strip()
        }
        
        # Handle boolean fields
        if pd.notna(row.get('temporary_blocking')):
            item['temporary_blocking'] = bool(row['temporary_blocking'])
        
        if pd.notna(row.get('permanent_blocking')):
            item['permanent_blocking'] = bool(row['permanent_blocking'])
        
        # Handle date fields
        if pd.notna(row.get('temporary_blocking_date')):
            if isinstance(row['temporary_blocking_date'], datetime):
                item['temporary_blocking_date'] = row['temporary_blocking_date'].isoformat()
            else:
                item['temporary_blocking_date'] = str(row['temporary_blocking_date'])
        
        if pd.notna(row.get('permanent_blocking_date')):
            if isinstance(row['permanent_blocking_date'], datetime):
                item['permanent_blocking_date'] = row['permanent_blocking_date'].isoformat()
            else:
                item['permanent_blocking_date'] = str(row['permanent_blocking_date'])
        
        return item

    def prepare_blocked_item(self, row: Dict[str, Any]) -> Dict[str, Any]:
        """Prepare blocked numbers item for DynamoDB."""
        item = {
            'CONTACT_PHONE': str(row['CONTACT_PHONE']).strip(),
            'COMMENTS': str(row.get('COMMENTS', '')).strip()
        }
        return item

    def batch_write_items(self, table, items: List[Dict[str, Any]], batch_size: int = 25):
        """Write items to DynamoDB in batches."""
        total_items = len(items)
        success_count = 0
        error_count = 0
        
        for i in range(0, total_items, batch_size):
            batch = items[i:i + batch_size]
            
            try:
                with table.batch_writer() as batch_writer:
                    for item in batch:
                        batch_writer.put_item(Item=item)
                
                success_count += len(batch)
                logger.info(f"Successfully uploaded batch {i//batch_size + 1}: {len(batch)} items")
                
            except ClientError as e:
                error_count += len(batch)
                logger.error(f"Error uploading batch {i//batch_size + 1}: {e}")
                continue
        
        logger.info(f"Upload completed: {success_count} successful, {error_count} failed")
        return success_count, error_count

    def upload_fraud_numbers(self, excel_file: str, sheet_name: str = None) -> tuple:
        """Upload fraud numbers from Excel to DynamoDB."""
        logger.info(f"Starting fraud numbers upload from {excel_file}")
        
        # Read Excel file
        df = self.read_excel_file(excel_file, sheet_name)
        
        # Validate required columns
        required_columns = ['id_call']
        missing_columns = [col for col in required_columns if col not in df.columns]
        if missing_columns:
            raise ValueError(f"Missing required columns: {missing_columns}")
        
        # Prepare items for DynamoDB
        items = []
        for _, row in df.iterrows():
            if pd.notna(row['id_call']):  # Skip rows with empty id_call
                item = self.prepare_fraud_item(row)
                items.append(item)
        
        logger.info(f"Prepared {len(items)} fraud number items for upload")
        
        # Upload to DynamoDB
        return self.batch_write_items(self.fraud_table, items)

    def upload_blocked_numbers(self, excel_file: str, sheet_name: str = None) -> tuple:
        """Upload blocked numbers from Excel to DynamoDB."""
        logger.info(f"Starting blocked numbers upload from {excel_file}")
        
        # Read Excel file
        df = self.read_excel_file(excel_file, sheet_name)
        
        # Validate required columns
        required_columns = ['CONTACT_PHONE']
        missing_columns = [col for col in required_columns if col not in df.columns]
        if missing_columns:
            raise ValueError(f"Missing required columns: {missing_columns}")
        
        # Prepare items for DynamoDB
        items = []
        for _, row in df.iterrows():
            if pd.notna(row['CONTACT_PHONE']):  # Skip rows with empty CONTACT_PHONE
                item = self.prepare_blocked_item(row)
                items.append(item)
        
        logger.info(f"Prepared {len(items)} blocked number items for upload")
        
        # Upload to DynamoDB
        return self.batch_write_items(self.blocked_table, items)

def main():
    parser = argparse.ArgumentParser(description='Upload Excel data to DynamoDB tables')
    parser.add_argument('--type', choices=['fraud', 'blocked'], required=True,
                        help='Type of data to upload (fraud or blocked)')
    parser.add_argument('--file', required=True, help='Path to Excel file')
    parser.add_argument('--sheet', help='Sheet name (optional)')
    parser.add_argument('--environment', default='dev', help='Environment (default: dev)')
    parser.add_argument('--region', default='us-east-1', help='AWS region (default: us-east-1)')
    parser.add_argument('--profile', help='AWS profile name (optional)')
    
    args = parser.parse_args()
    
    try:
        uploader = ExcelToDynamoUploader(args.environment, args.region, args.profile)
        
        if args.type == 'fraud':
            success, errors = uploader.upload_fraud_numbers(args.file, args.sheet)
            logger.info(f"Fraud numbers upload completed: {success} successful, {errors} errors")
        
        elif args.type == 'blocked':
            success, errors = uploader.upload_blocked_numbers(args.file, args.sheet)
            logger.info(f"Blocked numbers upload completed: {success} successful, {errors} errors")
        
        if errors > 0:
            sys.exit(1)
        
    except Exception as e:
        logger.error(f"Upload failed: {e}")
        sys.exit(1)

if __name__ == '__main__':
    main() 