# Deployment Guide: AWS Connect Survey Module

## Prerequisites

### Required Tools
- AWS CLI (v2.0+)
- SAM CLI (v1.70+)
- Node.js (v18.x)
- npm (v8.0+)

### AWS Account Setup
- Administrative access to AWS account
- AWS Connect instance configured
- Lex V2 bot permissions
- DynamoDB access

### Installation Commands
```bash
# Install AWS CLI
curl "https://awscli.amazonaws.com/awscli-exe-linux-x86_64.zip" -o "awscliv2.zip"
unzip awscliv2.zip
sudo ./aws/install

# Install SAM CLI
pip install aws-sam-cli

# Configure AWS credentials
aws configure
```

## Environment Setup

### 1. Clone Repository
```bash
git clone <repository-url>
cd talkia-pcs
```

### 2. Install Dependencies
```bash
npm install
```

### 3. Environment Configuration
Create environment-specific parameter files:

#### `parameters/dev.json`
```json
{
  "Environment": "dev",
  "LogLevel": "DEBUG",
  "TimeoutSeconds": 30
}
```

#### `parameters/prod.json`
```json
{
  "Environment": "prod",
  "LogLevel": "WARN",
  "TimeoutSeconds": 30
}
```

## Deployment Steps

### Development Environment

#### 1. Build Application
```bash
sam build
```

#### 2. Deploy to Development
```bash
sam deploy \
  --template-file template.yaml \
  --stack-name talkia-pcs-dev \
  --parameter-overrides file://parameters/dev.json \
  --capabilities CAPABILITY_IAM \
  --region us-east-1
```

#### 3. Populate Initial Data
```bash
# Invoke the populate questions function
aws lambda invoke \
  --function-name dev-pcs-hook \
  --payload '{"action": "populate"}' \
  response.json

# Verify the response
cat response.json
```

### Production Environment

#### 1. Build Application
```bash
sam build --use-container
```

#### 2. Deploy to Production
```bash
sam deploy \
  --template-file template.yaml \
  --stack-name talkia-pcs-prod \
  --parameter-overrides file://parameters/prod.json \
  --capabilities CAPABILITY_IAM \
  --region us-east-1 \
  --confirm-changeset
```

#### 3. Verify Deployment
```bash
# Check stack status
aws cloudformation describe-stacks \
  --stack-name talkia-pcs-prod \
  --query 'Stacks[0].StackStatus'

# List created resources
aws cloudformation list-stack-resources \
  --stack-name talkia-pcs-prod
```

## AWS Connect Configuration

### 1. Create Contact Flow

#### WhatsApp Contact Flow
The existing contact flow `SurveyModuleChat` has the following structure:

```yaml
Flow Name: SurveyModuleChat
Flow Type: Published
Entry Point: Welcome Message

Flow Structure:
  1. Welcome Message → Display survey invitation
  2. Connect to Lex Bot → Question 0 (Survey Acceptance)
     - Bot: 000-PostContactSurveyBot
     - Timeout: 600 seconds
     - questionId: "0"
  3. Check Response → Branch on "Sí" or "No"
  4. If "Sí" → Continue to Question 1
  5. If "No" → Thank you message → Disconnect
  
  Question Flow:
  - Question 1: Satisfaction Rating (1-5)
    - questionId: "1", Intent: NumericOpinion
    - Update flag attribute based on low ratings (1-3)
    
  - Question 2: Ease of Use Rating (1-5)  
    - questionId: "2", Intent: NumericOpinion
    - Update flag attribute based on low ratings (1-3)
    
  - Question 3: Problem Resolution (Yes/No)
    - questionId: "3", Intent: BinaryOpinion
    - Update flag attribute based on "No" response
    
  - Check Flag → If flag="true" → Additional Comments
  - Question 4: Want to Leave Comments? (Yes/No)
    - questionId: "4", Intent: BinaryOpinion
    
  - Question 5: Free Text Comment (Conditional)
    - questionId: "5", Intent: ClientComplaint
    
  Error Handling:
  - Invalid responses → Retry message → Return to question
  - Timeout → Expiry message → Disconnect
  - No matching condition → Default error handling
```

To import the contact flow:
1. Open AWS Connect console
2. Navigate to "Contact flows"
3. Click "Create contact flow" → "Import flow (beta)"
4. Upload the `contact-flow/SurveyModuleChat.json` file
5. Update the Lex bot ARN in all "ConnectParticipantWithLexBot" blocks:
   - Replace `UPDATE_WITH_YOUR_BOT_ARN` with your actual bot ARN
6. Save and publish the contact flow

#### Contact Flow Configuration Steps:
```bash
# Get your Lex bot ARN
aws lexv2-models describe-bot-alias \
  --bot-id <your-bot-id> \
  --bot-alias-id <your-alias-id> \
  --query 'BotAliasArn'

# Update the contact flow JSON file with your ARN before importing
sed -i 's|UPDATE_WITH_YOUR_BOT_ARN|<your-bot-arn>|g' contact-flow/SurveyModuleChat.json
```

#### Voice Contact Flow
Similar structure adapted for voice channel with:
- Play prompt blocks
- Get customer input blocks
- DTMF configuration

### 2. Lambda Function Integration

#### Set Function ARN
```bash
# Get function ARN
aws lambda get-function \
  --function-name dev-pcs-hook \
  --query 'Configuration.FunctionArn'

# Add to Connect contact flow
```

#### Configure Permissions
```bash
# Allow Connect to invoke Lambda
aws lambda add-permission \
  --function-name dev-pcs-hook \
  --statement-id AllowConnectInvoke \
  --action lambda:InvokeFunction \
  --principal connect.amazonaws.com \
  --source-arn arn:aws:connect:us-east-1:123456789012:instance/12345678-abcd-1234-efgh-123456789012
```

### 3. Lex Bot Configuration

#### Existing Lex V2 Bot Configuration
The contact flow uses an existing Lex V2 bot with the following configuration:

```yaml
Bot Name: 000-PostContactSurveyBot
Bot Alias: TestBotAlias
Bot ARN: arn:aws:lex:us-east-1:216207491789:bot-alias/LYCFMIVZCY/TSTALIASID
Session Timeout: 600 seconds (10 minutes)
Fulfillment: Lambda function integration
```

To create a similar bot for your environment:
```bash
# Create bot
aws lexv2-models create-bot \
  --bot-name 000-PostContactSurveyBot \
  --description "Post Contact Survey Bot for PCS module" \
  --role-arn arn:aws:iam::123456789012:role/LexServiceRole \
  --data-privacy '{"childDirected": false}' \
  --idle-session-ttl-in-seconds 600
```

#### Configure Intents
Create the following intents in Lex console:

1. **SurveyAccept**
   - Slot: `surveyConfirmation` (Custom slot type: SI, NO)
   - Sample utterances: "Sí", "No", "SI", "NO"

2. **NumericOpinion**
   - Slot: `numericRating` (Custom slot type: 1, 2, 3, 4, 5)
   - Sample utterances: "1", "2", "3", "4", "5"

3. **BinaryOpinion**
   - Slot: `binaryRating` (Custom slot type: SI, NO)
   - Sample utterances: "Sí", "No", "SI", "NO"

4. **ClientComplaint**
   - Slot: `complaint` (AMAZON.AlphaNumeric)
   - Sample utterances: Various text patterns

#### Set Fulfillment Lambda
```bash
# Configure Lambda fulfillment
aws lexv2-models put-bot-version \
  --bot-id <bot-id> \
  --bot-version DRAFT \
  --description "Survey bot version 1"
```

## Monitoring Setup

### 1. CloudWatch Dashboards

#### Create Dashboard
```bash
aws cloudwatch put-dashboard \
  --dashboard-name "PCS-Survey-Dashboard" \
  --dashboard-body file://monitoring/dashboard.json
```

#### Dashboard Configuration (`monitoring/dashboard.json`)
```json
{
  "widgets": [
    {
      "type": "metric",
      "properties": {
        "metrics": [
          ["AWS/Lambda", "Invocations", "FunctionName", "dev-pcs-hook"],
          ["AWS/Lambda", "Errors", "FunctionName", "dev-pcs-hook"],
          ["AWS/Lambda", "Duration", "FunctionName", "dev-pcs-hook"]
        ],
        "period": 300,
        "stat": "Sum",
        "region": "us-east-1",
        "title": "Lambda Metrics"
      }
    },
    {
      "type": "metric",
      "properties": {
        "metrics": [
          ["AWS/DynamoDB", "ConsumedReadCapacityUnits", "TableName", "talkia-dev-PCS-Connect"],
          ["AWS/DynamoDB", "ConsumedWriteCapacityUnits", "TableName", "talkia-dev-PCS-Connect"]
        ],
        "period": 300,
        "stat": "Sum",
        "region": "us-east-1",
        "title": "DynamoDB Metrics"
      }
    }
  ]
}
```

### 2. CloudWatch Alarms

#### Lambda Error Alarm
```bash
aws cloudwatch put-metric-alarm \
  --alarm-name "PCS-Lambda-Errors" \
  --alarm-description "PCS Lambda function errors" \
  --metric-name Errors \
  --namespace AWS/Lambda \
  --statistic Sum \
  --period 300 \
  --threshold 5 \
  --comparison-operator GreaterThanThreshold \
  --dimensions Name=FunctionName,Value=dev-pcs-hook \
  --evaluation-periods 2 \
  --alarm-actions arn:aws:sns:us-east-1:123456789012:pcs-alerts
```

#### DynamoDB Throttle Alarm
```bash
aws cloudwatch put-metric-alarm \
  --alarm-name "PCS-DynamoDB-Throttles" \
  --alarm-description "DynamoDB throttling events" \
  --metric-name SystemErrors \
  --namespace AWS/DynamoDB \
  --statistic Sum \
  --period 300 \
  --threshold 1 \
  --comparison-operator GreaterThanOrEqualToThreshold \
  --dimensions Name=TableName,Value=talkia-dev-PCS-Connect \
  --evaluation-periods 1 \
  --alarm-actions arn:aws:sns:us-east-1:123456789012:pcs-alerts
```

## Testing

### 1. Unit Tests
```bash
# Run unit tests
npm test

# Run with coverage
npm run test:coverage
```

### 2. Integration Tests
```bash
# Test Lambda function directly
aws lambda invoke \
  --function-name dev-pcs-hook \
  --payload file://test/payloads/survey-accept.json \
  output.json

# Verify response
cat output.json
```

### 3. End-to-End Testing

#### WhatsApp Channel Test
1. Configure test WhatsApp number
2. Initiate conversation with agent
3. End conversation to trigger survey
4. Complete survey flow
5. Verify data in DynamoDB

#### Voice Channel Test
1. Call test number
2. Complete agent interaction
3. Stay on line for survey
4. Provide DTMF responses
5. Verify data storage

## Troubleshooting

### Common Issues

#### 1. Lambda Function Errors
**Symptom**: Function returns 500 errors
**Solution**:
```bash
# Check CloudWatch logs
aws logs describe-log-groups \
  --log-group-name-prefix /aws/lambda/dev-pcs-hook

# View recent logs
aws logs tail /aws/lambda/dev-pcs-hook --follow
```

#### 2. DynamoDB Access Issues
**Symptom**: Cannot write to table
**Solution**:
```bash
# Check IAM permissions
aws iam get-role-policy \
  --role-name dev-pcs-hook-role \
  --policy-name DynamoDBCrudPolicy

# Test table access
aws dynamodb describe-table \
  --table-name talkia-dev-PCS-Connect
```

#### 3. Connect Integration Issues
**Symptom**: Survey not triggered after contact
**Solution**:
- Verify Lambda permissions for Connect
- Check contact flow configuration
- Validate function ARN in contact flow

### Debug Commands

#### Check Stack Status
```bash
aws cloudformation describe-stacks \
  --stack-name talkia-pcs-dev \
  --query 'Stacks[0].StackStatus'
```

#### View Lambda Logs
```bash
sam logs -n PCSHook --stack-name talkia-pcs-dev --tail
```

#### Test DynamoDB Operations
```bash
# List items
aws dynamodb scan \
  --table-name talkia-dev-PCS-Connect \
  --max-items 10

# Get specific item
aws dynamodb get-item \
  --table-name talkia-dev-PCS-Connect \
  --key '{"questionId": {"S": "1"}, "sessionId": {"S": "template"}}'
```

## Rollback Procedures

### 1. Lambda Function Rollback
```bash
# List function versions
aws lambda list-versions-by-function \
  --function-name dev-pcs-hook

# Rollback to previous version
aws lambda update-function-configuration \
  --function-name dev-pcs-hook \
  --code-sha-256 <previous-version-sha>
```

### 2. Stack Rollback
```bash
# Cancel current deployment
aws cloudformation cancel-update-stack \
  --stack-name talkia-pcs-dev

# Rollback to previous version
aws cloudformation update-stack \
  --stack-name talkia-pcs-dev \
  --use-previous-template \
  --parameters ParameterKey=Environment,UsePreviousValue=true
```

## Maintenance

### 1. Regular Tasks

#### Update Dependencies
```bash
# Update npm packages
npm audit fix

# Update SAM CLI
pip install --upgrade aws-sam-cli
```

#### Clean Up Logs
```bash
# Set log retention
aws logs put-retention-policy \
  --log-group-name /aws/lambda/dev-pcs-hook \
  --retention-in-days 30
```

### 2. Backup Procedures

#### DynamoDB Backup
```bash
# Create on-demand backup
aws dynamodb create-backup \
  --table-name talkia-prod-PCS-Connect \
  --backup-name pcs-backup-$(date +%Y%m%d)
```

#### Export Survey Data
```bash
# Export to S3
aws dynamodb export-table-to-point-in-time \
  --table-arn arn:aws:dynamodb:us-east-1:123456789012:table/talkia-prod-PCS-Connect \
  --s3-bucket survey-data-exports \
  --s3-prefix pcs-export-$(date +%Y%m%d)
```

## Security Checklist

### Pre-Deployment Security Review
- [ ] IAM policies follow least privilege principle
- [ ] Environment variables don't contain secrets
- [ ] Input validation implemented
- [ ] Error messages don't expose sensitive data
- [ ] Logging doesn't capture PII
- [ ] DynamoDB encryption enabled
- [ ] Lambda functions use dedicated IAM roles

### Post-Deployment Security Verification
- [ ] Function permissions verified
- [ ] Network security groups configured
- [ ] CloudTrail logging enabled
- [ ] Access patterns monitored
- [ ] Penetration testing completed

## Performance Optimization

### 1. Lambda Optimization
```bash
# Increase memory allocation
aws lambda update-function-configuration \
  --function-name dev-pcs-hook \
  --memory-size 256

# Enable provisioned concurrency
aws lambda put-provisioned-concurrency-config \
  --function-name dev-pcs-hook \
  --provisioned-concurrency-config ProvisionedConcurrencyUnits=10
```

### 2. DynamoDB Optimization
```bash
# Enable auto-scaling
aws application-autoscaling register-scalable-target \
  --service-namespace dynamodb \
  --resource-id table/talkia-prod-PCS-Connect \
  --scalable-dimension dynamodb:table:WriteCapacityUnits \
  --min-capacity 5 \
  --max-capacity 100
```

## Support and Maintenance Contacts

### Development Team
- **Lead Developer**: [email]
- **DevOps Engineer**: [email]
- **QA Engineer**: [email]

### Infrastructure Team
- **AWS Architect**: [email]
- **Security Engineer**: [email]
- **Monitoring Specialist**: [email]

### Escalation Path
1. Level 1: Development Team
2. Level 2: Infrastructure Team
3. Level 3: AWS Support (Enterprise)

---

This deployment guide provides comprehensive instructions for setting up the AWS Connect Survey module across different environments. Follow the steps sequentially and refer to the troubleshooting section for common issues. 