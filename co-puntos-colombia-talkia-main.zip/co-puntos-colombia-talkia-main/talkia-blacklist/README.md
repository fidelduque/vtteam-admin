# AWS Connect Survey Module - Talkia PCS

## Overview

The Talkia PCS (Puntos Colombia Survey) module is a comprehensive AWS-based solution designed to collect customer satisfaction feedback through both **digital channels (WhatsApp)** and **voice channels (telephone)**. The solution integrates with Amazon Connect to automatically trigger surveys after customer interactions end.

## Architecture

### Components

1. **AWS Lambda Functions**
   - `pcs-hook`: Main survey orchestration function
   - `update-answer`: Function to update survey responses in real-time

2. **Amazon DynamoDB**
   - `talkia-{env}-PCS-Connect`: Survey data storage table

3. **Amazon Connect Integration**
   - Contact flows for voice and chat channels
   - Lex bot integration for natural language processing

### Data Flow

```
Customer Interaction Ends → Connect Flow → Lambda Hook → Survey Questions → Customer Response → DynamoDB Storage
```

## Survey Flow Logic

### Digital Channel (WhatsApp)

#### Initial Trigger
When an advisor closes a WhatsApp conversation, the system triggers:

**Welcome Message:**
```
¡Tu opinión es muy importante para nosotros!
Te invitamos a realizar una breve encuesta de satisfacción relacionada con tu experiencia durante la conversación con el asesor.
¿Deseas realizar la encuesta?
```

**Options:** Interactive buttons (Sí/No)

#### Question Sequence

1. **Satisfaction Rating (Question 1)**
   ```
   ¿Qué tan satisfecho te encuentras con la experiencia que tuviste en el canal de Whatsapp de Puntos Colombia?
   Selecciona de 1 a 5 donde 1 es "Muy insatisfecho" y 5 es "Muy satisfecho".
   ```
   - Interactive list menu with options 1-5
   - Emojis: 1☹️, 2😕, 3😐, 4😀, 5🤩

2. **Ease of Use Rating (Question 2)**
   ```
   ¿Qué tan fácil fue para ti interactuar con Puntos Colombia a través del Whatsapp?
   Selecciona de 1 a 5, donde 1 es "Muy difícil", y 5 es "Muy fácil".
   ```
   - Interactive list menu with options 1-5
   - Emojis: 1☹️, 2😕, 3😐, 4😀, 5🤩

3. **Resolution Confirmation (Question 3)**
   ```
   ¿Recibiste solución a tu solicitud o requerimiento?
   ```
   - Interactive buttons (Sí/No)

4. **Additional Comments (Question 4)** - *Conditional*
   - Triggered if: Ratings 1-3 in Q1/Q2 OR "No" in Q3
   ```
   ¿Quieres compartirnos algún comentario adicional?
   Selecciona: "Sí" Para dejar tu mensaje. "No" Para finalizar.
   ```

5. **Free Text Comment (Question 5)** - *If Q4 = Yes*
   ```
   Escribe por favor tu comentario de forma breve y en un solo mensaje.
   ```

#### Timeout Handling
- **Timeout Period:** 10 minutes
- **Timeout Message:**
  ```
  ¡La encuesta ha expirado!
  Gracias por tu tiempo.
  ¡Hasta pronto!
  ```

### Voice Channel (Telephone)

Similar flow adapted for voice interactions with DTMF inputs and voice prompts.

## Technical Implementation

### Question Management

The system pre-populates question templates in DynamoDB:

```javascript
const questions = [
    {
        questionId: "0", // Survey acceptance
        questionText: "¿Deseas realizar la encuesta?"
    },
    {
        questionId: "1", // Satisfaction rating
        questionText: "¿Qué tan satisfecho te encuentras..."
    },
    // ... additional questions
];
```

### WhatsApp Interactive Templates

#### Numeric Rating Menu (1-5 scale)
```javascript
function generateNumericMenu() {
    return {
        templateType: "WhatsAppInteractiveList",
        version: "1.0",
        data: {
            content: {
                title: "Opciones disponibles",
                body: { text: "Seleccione una opción para continuar" },
                action: {
                    button: "Opciones disponibles",
                    sections: [{
                        title: "Opciones disponibles",
                        rows: [
                            { id: "1", title: "1" },
                            { id: "2", title: "2" },
                            { id: "3", title: "3" },
                            { id: "4", title: "4" },
                            { id: "5", title: "5" }
                        ]
                    }]
                }
            }
        }
    };
}
```

#### Binary Choice Menu (Yes/No)
```javascript
function generateBinaryMenu() {
    return {
        templateType: "WhatsAppInteractiveReplyButton",
        version: "1.0",
        data: {
            content: {
                title: "Opciones disponibles",
                body: { text: "Seleccione una opción para continuar" },
                action: {
                    buttons: [
                        { type: "reply", reply: { id: "SI", title: "Sí" } },
                        { type: "reply", reply: { id: "NO", title: "No" } }
                    ]
                }
            }
        }
    };
}
```

### Intent Handlers

The system handles four main intent types:

1. **SurveyAccept** - Initial survey acceptance
2. **NumericOpinion** - 1-5 rating questions
3. **BinaryOpinion** - Yes/No questions
4. **ClientComplaint** - Free text feedback

### Response Processing Logic

#### Low Rating Detection
```javascript
const lowRatings = ['1', '2', '3'];
if (lowRatings.includes(userInput)) {
    sessionAttributes.flag = "true";
    console.log('Setting session attribute flagged to true for low rating');
}
```

#### Input Validation
The system validates responses through multiple layers:
- Slot values from Lex
- Intent interpretations
- Direct input transcript matching

### Data Storage Schema

**DynamoDB Table Structure:**
```
Primary Key: questionId (String)
Sort Key: sessionId (String)
Attributes:
- questionText (String)
- answer (String)
- updatedAt (ISO String)
```

**Example Record:**
```json
{
    "questionId": "1",
    "sessionId": "contact-123456",
    "questionText": "¿Qué tan satisfecho te encuentras...",
    "answer": "4",
    "updatedAt": "2024-01-15T10:30:00.000Z"
}
```

## Deployment

### Prerequisites
- AWS CLI configured
- SAM CLI installed
- Node.js 18.x

### Deploy Commands
```bash
# Build the application
sam build

# Deploy to development environment
sam deploy --parameter-overrides Environment=dev

# Deploy to production environment
sam deploy --parameter-overrides Environment=prod
```

### Environment Variables
```yaml
Environment:
  Variables:
    PCS_TABLE: !Ref PCSTable
```

## Configuration

### AWS Connect Integration

1. **Contact Flow Setup**
   - Contact Flow Name: `SurveyModuleChat`
   - Flow Type: Post-contact survey flow
   - Timeout Configuration: 600 seconds (10 minutes)
   - Lambda function ARN integration for survey processing

2. **Lex Bot Configuration**
   - Bot Name: `000-PostContactSurveyBot`
   - Bot Alias: `TestBotAlias`
   - Bot ARN: `arn:aws:lex:us-east-1:216207491789:bot-alias/LYCFMIVZCY/TSTALIASID`
   - Intents: SurveyAccept, NumericOpinion, BinaryOpinion, ClientComplaint
   - Session timeout: 600 seconds
   - Fulfillment Lambda function integration

### Session Attributes

Required session attributes:
- `questionId`: Current question identifier (0-5)
- `sessionId`: Unique session/contact identifier  
- `flag`: Indicates if additional comments are needed (set to "true" for low ratings)

### Contact Flow Messages

The actual messages used in the contact flow:

#### Welcome Message
```
¡Tu opinión es muy importante para nosotros!

Te invitamos a realizar una breve encuesta de satisfacción relacionada con tu experiencia durante la conversación con el asesor.
```

#### Question 1 (Satisfaction Rating)
```
¿Qué tan satisfecho te encuentras con la experiencia que tuviste en el canal de Whatsapp de Puntos Colombia? 

Selecciona de 1 a 5 donde 1 es "Muy insatisfecho" y 5 es "Muy satisfecho".

1 ☹️ Muy insatisfecho
2 😕 Insatisfecho
3 😐 Ni satisfecho e insatisfecho
4 😀 Satisfecho
5 🤩 Muy satisfecho
```

#### Question 2 (Ease of Use)
```
¿Qué tan fácil fue para ti interactuar con Puntos Colombia a través del Whatsapp? 

Selecciona de 1 a 5, donde 1 es "Muy difícil", y 5 es "Muy fácil".

1 ☹️ Muy difícil
2 😕 Difícil
3 😐 Neutral
4 😀 Fácil
5 🤩 Muy fácil
```

#### Question 3 (Problem Resolution)
```
¿Recibiste solución a tu solicitud o requerimiento?
```

#### Question 4 (Additional Comments - Conditional)
```
¿Quieres compartirnos algún comentario adicional?

Selecciona:
"Sí" Para dejar tu mensaje.
"No" Para finalizar.
```

#### Error Handling Message
```
¡Lo siento! 😓 No logré entender tu respuesta, asegúrate que hayas seleccionado la opción correcta.
```

#### Timeout Message
```
¡La encuesta ha expirado!

Gracias por tu tiempo.

¡Hasta pronto!
```

#### Thank You Message (Survey Completion)
```
¡Muchas gracias por tu tiempo! 

Tu opinión es muy importante para nosotros y tus respuestas nos ayudarán a mejorar cada día más.
```

#### Decline Survey Message
```
¡Muchas gracias por elegir nuestros canales digitales!

¡Hasta Pronto!
```

## API Reference

### Lambda Functions

#### surveyHook
**Purpose:** Main survey orchestration
**Handler:** `index.surveyHook`
**Timeout:** 30 seconds

**Event Structure:**
```json
{
    "sessionState": {
        "intent": {
            "name": "IntentName",
            "slots": {},
            "state": "InProgress"
        },
        "sessionAttributes": {}
    },
    "inputTranscript": "user input",
    "interpretations": []
}
```

#### updateAnswer
**Purpose:** Update survey responses
**Handler:** `index.updateAnswer`
**Timeout:** 30 seconds

**Parameters:**
```json
{
    "Details": {
        "Parameters": {
            "questionId": "1",
            "answer": "4",
            "contactId": "contact-123456"
        }
    }
}
```

## Monitoring and Troubleshooting

### CloudWatch Logs
- Function logs available in `/aws/lambda/{function-name}`
- Structured logging with JSON format
- Error tracking and debugging information

### Common Issues

1. **Missing Required Parameters**
   - Ensure all required parameters are passed from Connect
   - Check session attributes configuration

2. **DynamoDB Access Issues**
   - Verify IAM permissions
   - Check table name environment variable

3. **WhatsApp Template Rendering**
   - Validate JSON structure
   - Check template version compatibility

## Data Export and Analytics

### Survey Response Retrieval
Responses can be queried from DynamoDB using:
- `questionId` and `sessionId` for specific responses
- Scan operations for bulk data export
- Custom queries for analytics and reporting

### Reporting Capabilities
- Complete and partial survey responses
- Response time tracking
- Satisfaction score analytics
- Comment sentiment analysis potential

## Security Considerations

- All data is encrypted at rest in DynamoDB
- Lambda functions use IAM roles with minimal required permissions
- Input validation prevents injection attacks
- Session isolation through unique session IDs

## Scalability

- Serverless architecture automatically scales with demand
- DynamoDB on-demand billing handles traffic spikes
- Lambda concurrent execution limits can be adjusted
- Regional deployment for global availability

## Contact Flow Implementation

### Actual Flow Structure
The `SurveyModuleChat` contact flow includes:

#### Core Components
- **26 Actions** total in the flow
- **10-minute timeout** per question (600 seconds)
- **Conditional branching** based on session flags
- **Error handling** with retry mechanisms
- **Multi-language support** (Spanish implementation)

#### Key Flow Actions
1. **Message Blocks**: Display survey questions and responses
2. **Lex Bot Integration**: Handle customer input processing
3. **Comparison Blocks**: Evaluate responses and route flow
4. **Attribute Updates**: Manage session state and flags
5. **Disconnect Blocks**: Graceful conversation termination

#### Session Management
- **Question ID tracking**: Sequential question progression (0-5)
- **Flag attribute**: Conditional logic for additional comments
- **Error state handling**: Graceful recovery from invalid inputs
- **Timeout management**: Automatic expiry handling

### Flow Import Instructions
1. Use the provided `contact-flow/SurveyModuleChat.json` file
2. Update Lex bot ARN references before importing
3. Verify all message texts match your language requirements
4. Test flow functionality in Connect console

## Future Enhancements

1. **Multi-language Support**
   - Dynamic question text based on customer language preference
   - Localized response options

2. **Advanced Analytics**
   - Real-time dashboards
   - Trend analysis
   - Automated alerts for low satisfaction scores

3. **Integration Improvements**  
   - CRM system integration
   - Email survey fallback
   - SMS survey option

4. **AI/ML Features**
   - Sentiment analysis of text responses
   - Predictive satisfaction scoring
   - Automated response categorization 