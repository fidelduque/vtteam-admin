'use strict';

import { DynamoDB } from '@aws-sdk/client-dynamodb';
import { DynamoDBDocument } from '@aws-sdk/lib-dynamodb';

const dynamodb = DynamoDBDocument.from(new DynamoDB());

const FRAUD_TABLE = process.env.FRAUD_TABLE;
const BLOCKED_TABLE = process.env.BLOCKED_TABLE;

const createResponse = (statusCode, body) => ({
  statusCode,
  body: JSON.stringify(body)
});

const checkPhoneNumberInFraudDatabase = async (phoneNumber) => {
  try {
    const fraudCheck = await dynamodb.get({
      TableName: FRAUD_TABLE,
      Key: { id_call: phoneNumber }
    });

    const existingFraudData = fraudCheck.Item;

    if (existingFraudData) {
      // Update check count and last checked timestamp
      try {
        await dynamodb.update({
          TableName: FRAUD_TABLE,
          Key: { id_call: phoneNumber },
          UpdateExpression: 'SET lastChecked = :timestamp, checkCount = if_not_exists(checkCount, :zero) + :inc',
          ExpressionAttributeValues: {
            ':timestamp': new Date().toISOString(),
            ':zero': 0,
            ':inc': 1
          }
        });
      } catch (error) {
        console.error('Error updating fraud record:', error);
      }
    }

    return {
      isFraud: !!existingFraudData,
      fraudData: existingFraudData
    };
  } catch (error) {
    console.error('Error checking fraud database:', error);
    return {
      isFraud: false,
      fraudData: null
    };
  }
};

const checkPhoneNumberInBlockedDatabase = async (phoneNumber) => {
  try {
    const blockedCheck = await dynamodb.get({
      TableName: BLOCKED_TABLE,
      Key: { CONTACT_PHONE: phoneNumber }
    });

    const existingBlockedData = blockedCheck.Item;

    if (existingBlockedData) {
      // Update check count and last checked timestamp
      try {
        await dynamodb.update({
          TableName: BLOCKED_TABLE,
          Key: { CONTACT_PHONE: phoneNumber },
          UpdateExpression: 'SET lastChecked = :timestamp, checkCount = if_not_exists(checkCount, :zero) + :inc',
          ExpressionAttributeValues: {
            ':timestamp': new Date().toISOString(),
            ':zero': 0,
            ':inc': 1
          }
        });
      } catch (error) {
        console.error('Error updating blocked record:', error);
      }
    }

    return {
      isBlocked: !!existingBlockedData,
      blockedData: existingBlockedData
    };
  } catch (error) {
    console.error('Error checking blocked database:', error);
    return {
      isBlocked: false,
      blockedData: null
    };
  }
};

const formatPhoneNumber = (phoneNumber) => {
  if (phoneNumber.startsWith('+57')) {
    return phoneNumber.split('+57')[1];
  }
  return phoneNumber;
};

export const checkPhoneNumber = async (event) => {
  try {
    console.log('Received event:', JSON.stringify(event, null, 2));

    // Get phone number from event structure
    const { phoneNumber } = event.Details.Parameters;

    if (!phoneNumber) {
      return createResponse(400, {
        error: 'Phone number is required'
      });
    }

    const formattedPhoneNumber = formatPhoneNumber(phoneNumber);
    
    // Check both fraud and blocked databases in parallel
    const [fraudResult, blockedResult] = await Promise.all([
      checkPhoneNumberInFraudDatabase(formattedPhoneNumber),
      checkPhoneNumberInBlockedDatabase(formattedPhoneNumber)
    ]);

    const response = {
      phoneNumber: formattedPhoneNumber,
      isFraud: fraudResult.isFraud,
      isBlocked: blockedResult.isBlocked,
      fraudData: fraudResult.fraudData,
      blockedData: blockedResult.blockedData,
      timestamp: new Date().toISOString()
    };

    console.log('Response:', JSON.stringify(response, null, 2));
    return createResponse(200, response);

  } catch (error) {
    console.error('Error in checkPhoneNumber:', error);
    
    return createResponse(500, {
      error: 'Internal server error',
      message: 'Failed to process phone number check'
    });
  }
}; 