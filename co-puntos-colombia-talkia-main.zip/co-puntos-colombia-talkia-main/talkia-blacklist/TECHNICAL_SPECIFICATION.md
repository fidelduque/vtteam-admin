# Technical Specification: AWS Connect Survey Module

## System Requirements

### Functional Requirements

#### FR-001: Multi-Channel Support
- **Requirement**: Support both digital (WhatsApp) and voice (telephone) channels
- **Implementation**: Channel-specific message templates and input handling
- **Validation**: Automated testing for both channel types

#### FR-002: Survey Question Management
- **Requirement**: Pre-defined survey questions with dynamic content
- **Implementation**: DynamoDB template storage with questionId-based retrieval
- **Validation**: Question text validation and template integrity checks

#### FR-003: Response Storage
- **Requirement**: Store complete and partial survey responses
- **Implementation**: Real-time DynamoDB writes with session tracking
- **Validation**: Data persistence verification and retrieval testing

#### FR-004: Conditional Logic
- **Requirement**: Trigger additional questions based on response scores
- **Implementation**: Low rating detection (1-3) and session flag management
- **Validation**: Logic flow testing with various rating combinations

#### FR-005: Timeout Management
- **Requirement**: 10-minute timeout for survey completion
- **Implementation**: Connect flow timeout configuration
- **Validation**: Timeout behavior verification

### Non-Functional Requirements

#### NFR-001: Performance
- **Response Time**: < 3 seconds for question delivery
- **Throughput**: Support 1000+ concurrent surveys
- **Scalability**: Auto-scaling with serverless architecture

#### NFR-002: Reliability
- **Availability**: 99.9% uptime SLA
- **Error Handling**: Graceful degradation on failures
- **Data Integrity**: ACID compliance for survey responses

#### NFR-003: Security
- **Encryption**: Data at rest and in transit
- **Access Control**: IAM-based permissions
- **Input Validation**: Prevent injection attacks

## API Specifications

### Lambda Function: surveyHook

#### Input Event Schema
```json
{
  "type": "object",
  "properties": {
    "sessionState": {
      "type": "object",
      "properties": {
        "intent": {
          "type": "object",
          "properties": {
            "name": {
              "type": "string",
              "enum": ["SurveyAccept", "NumericOpinion", "BinaryOpinion", "ClientComplaint"]
            },
            "state": {
              "type": "string",
              "enum": ["InProgress", "Fulfilled", "Failed"]
            },
            "slots": {
              "type": "object"
            }
          },
          "required": ["name", "state"]
        },
        "sessionAttributes": {
          "type": "object",
          "properties": {
            "questionId": {
              "type": "string",
              "pattern": "^[0-5]$"
            },
            "sessionId": {
              "type": "string"
            },
            "flag": {
              "type": "string",
              "enum": ["true", "false"]
            }
          }
        }
      },
      "required": ["intent"]
    },
    "inputTranscript": {
      "type": "string"
    },
    "interpretations": {
      "type": "array"
    },
    "invocationSource": {
      "type": "string",
      "enum": ["DialogCodeHook", "FulfillmentCodeHook"]
    }
  },
  "required": ["sessionState"]
}
```

#### Response Schema
```json
{
  "type": "object",
  "properties": {
    "sessionState": {
      "type": "object",
      "properties": {
        "dialogAction": {
          "type": "object",
          "properties": {
            "type": {
              "type": "string",
              "enum": ["Close", "ElicitSlot", "ElicitIntent"]
            },
            "slotToElicit": {
              "type": "string"
            }
          },
          "required": ["type"]
        },
        "intent": {
          "type": "object",
          "properties": {
            "name": {
              "type": "string"
            },
            "state": {
              "type": "string",
              "enum": ["InProgress", "Fulfilled", "Failed"]
            },
            "slots": {
              "type": "object"
            }
          },
          "required": ["name", "state"]
        },
        "sessionAttributes": {
          "type": "object"
        }
      },
      "required": ["dialogAction", "intent"]
    },
    "messages": {
      "type": "array",
      "items": {
        "type": "object",
        "properties": {
          "contentType": {
            "type": "string",
            "enum": ["PlainText", "CustomPayload"]
          },
          "content": {
            "type": "string"
          }
        },
        "required": ["contentType", "content"]
      }
    }
  },
  "required": ["sessionState"]
}
```

### Lambda Function: updateAnswer

#### Input Parameters Schema
```json
{
  "type": "object",
  "properties": {
    "Details": {
      "type": "object",
      "properties": {
        "Parameters": {
          "type": "object",
          "properties": {
            "questionId": {
              "type": "string",
              "pattern": "^[0-5]$"
            },
            "answer": {
              "type": "string",
              "minLength": 1,
              "maxLength": 1000
            },
            "contactId": {
              "type": "string",
              "minLength": 1
            }
          },
          "required": ["questionId", "answer", "contactId"]        }
      },
      "required": ["Parameters"]
    }
  },
  "required": ["Details"]
}
```

## Data Models

### DynamoDB Table Schema

#### Table: talkia-{env}-PCS-Connect

```yaml
TableName: talkia-{env}-PCS-Connect
AttributeDefinitions:
  - AttributeName: questionId
    AttributeType: S
  - AttributeName: sessionId
    AttributeType: S
KeySchema:
  - AttributeName: questionId
    KeyType: HASH
  - AttributeName: sessionId
    KeyType: RANGE
BillingMode: PAY_PER_REQUEST
```

#### Item Structure
```json
{
  "questionId": {
    "S": "1"
  },
  "sessionId": {
    "S": "contact-12345678-abcd-1234-efgh-123456789012"
  },
  "questionText": {
    "S": "¿Qué tan satisfecho te encuentras con la experiencia que tuviste en el canal de Whatsapp de Puntos Colombia?"
  },
  "answer": {
    "S": "4"
  },
  "updatedAt": {
    "S": "2024-01-15T10:30:00.000Z"
  }
}
```

### Question Template Configuration

```javascript
const QUESTION_TEMPLATES = {
  "0": {
    "questionText": "¿Deseas realizar la encuesta?",
    "responseType": "binary",
    "options": ["SI", "NO"]
  },
  "1": {
    "questionText": "¿Qué tan satisfecho te encuentras con la experiencia que tuviste en el canal de Whatsapp de Puntos Colombia?\n\nSelecciona de 1 a 5 donde 1 es \"Muy insatisfecho\" y 5 es \"Muy satisfecho\".\n\n1 ☹️ Muy insatisfecho\n2 😕 Insatisfecho\n3 😐 Ni satisfecho e insatisfecho\n4 😀 Satisfecho\n5 🤩 Muy satisfecho",
    "responseType": "numeric",
    "options": ["1", "2", "3", "4", "5"],
    "lowRatingThreshold": 3
  },
  "2": {
    "questionText": "¿Qué tan fácil fue para ti interactuar con Puntos Colombia a través del Whatsapp?\n\nSelecciona de 1 a 5, donde 1 es \"Muy difícil\", y 5 es \"Muy fácil\".\n\n1 ☹️ Muy difícil\n2 😕 Difícil\n3 😐 Neutral\n4 😀 Fácil\n5 🤩 Muy fácil",
    "responseType": "numeric",
    "options": ["1", "2", "3", "4", "5"],
    "lowRatingThreshold": 3
  },
  "3": {
    "questionText": "¿Recibiste solución a tu solicitud o requerimiento?",
    "responseType": "binary",
    "options": ["SI", "NO"]
  },
  "4": {
    "questionText": "¿Quieres compartirnos algún comentario adicional?\n\nSelecciona:\n\"Sí\" Para dejar tu mensaje.\n\"No\" Para finalizar.",
    "responseType": "binary",
    "options": ["SI", "NO"],
    "conditional": true
  },
  "5": {
    "questionText": "Escribe por favor tu comentario de forma breve y en un solo mensaje.",
    "responseType": "freetext",
    "conditional": true
  }
};
```

## WhatsApp Template Specifications

### Interactive List Template
```json
{
  "templateType": "WhatsAppInteractiveList",
  "version": "1.0",
  "data": {
    "content": {
      "title": "Opciones disponibles",
      "body": {
        "text": "Seleccione una opción para continuar"
      },
      "action": {
        "button": "Opciones disponibles",
        "sections": [
          {
            "title": "Opciones disponibles",
            "rows": [
              {"id": "1", "title": "1"},
              {"id": "2", "title": "2"},
              {"id": "3", "title": "3"},
              {"id": "4", "title": "4"},
              {"id": "5", "title": "5"}
            ]
          }
        ]
      }
    }
  }
}
```

### Interactive Reply Button Template
```json
{
  "templateType": "WhatsAppInteractiveReplyButton",
  "version": "1.0",
  "data": {
    "content": {
      "title": "Opciones disponibles",
      "body": {
        "text": "Seleccione una opción para continuar"
      },
      "action": {
        "buttons": [
          {
            "type": "reply",
            "reply": {
              "id": "SI",
              "title": "Sí"
            }
          },
          {
            "type": "reply",
            "reply": {
              "id": "NO",
              "title": "No"
            }
          }
        ]
      }
    }
  }
}
```

## Error Handling Specifications

### Error Response Format
```json
{
  "statusCode": 400,
  "body": {
    "error": "Missing required parameters",
    "message": "questionId, answer, and contactId are required",
    "timestamp": "2024-01-15T10:30:00.000Z",
    "requestId": "12345678-abcd-1234-efgh-123456789012"
  }
}
```

### Error Codes and Messages

| Error Code | Message | Cause | Resolution |
|------------|---------|--------|------------|
| 400 | Missing required parameters | Required parameters not provided | Check request payload |
| 403 | Access denied | Insufficient IAM permissions | Update IAM policies |
| 404 | Question not found | Invalid questionId | Verify question exists |
| 500 | Internal server error | Unexpected system error | Check CloudWatch logs |
| 503 | Service unavailable | Downstream service failure | Retry request |

## Performance Specifications

### Latency Requirements

| Operation | Target Latency | Maximum Latency |
|-----------|----------------|-----------------|
| Question Delivery | < 1 second | 3 seconds |
| Response Processing | < 2 seconds | 5 seconds |
| Database Write | < 500ms | 1 second |
| Template Generation | < 200ms | 500ms |

### Throughput Requirements

| Metric | Target | Maximum |
|--------|--------|---------|
| Concurrent Surveys | 500 | 1000 |
| Requests/Second | 100 | 500 |
| Database Operations/Second | 200 | 1000 |

## Security Specifications

### IAM Policy Template
```json
{
  "Version": "2012-10-17",
  "Statement": [
    {
      "Effect": "Allow",
      "Action": [
        "dynamodb:PutItem",
        "dynamodb:UpdateItem",
        "dynamodb:GetItem",
        "dynamodb:Query"
      ],
      "Resource": "arn:aws:dynamodb:*:*:table/talkia-*-PCS-Connect"
    },
    {
      "Effect": "Allow",
      "Action": [
        "logs:CreateLogGroup",
        "logs:CreateLogStream",
        "logs:PutLogEvents"
      ],
      "Resource": "arn:aws:logs:*:*:*"
    }
  ]
}
```

### Input Validation Rules

1. **Question ID Validation**
   - Pattern: `^[0-5]$`
   - Description: Must be a single digit from 0 to 5

2. **Session ID Validation**
   - Pattern: `^[a-zA-Z0-9-_]{1,128}$`
   - Description: Alphanumeric with hyphens and underscores

3. **Answer Validation**
   - Numeric answers: `^[1-5]$`
   - Binary answers: `^(SI|NO|Sí|No|si|no)$`
   - Free text: Max 1000 characters, sanitized input

4. **Intent Name Validation**
   - Enum: `["SurveyAccept", "NumericOpinion", "BinaryOpinion", "ClientComplaint"]`

## Testing Specifications

### Unit Test Coverage
- Target: 90% code coverage
- Critical functions: 100% coverage
- Error handling: 100% coverage

### Integration Test Scenarios

1. **End-to-End Survey Flow**
   - Complete survey with all questions
   - Partial survey with early termination
   - Low rating path with additional comments

2. **Channel-Specific Testing**
   - WhatsApp interactive templates
   - Voice channel DTMF inputs
   - Cross-channel consistency

3. **Error Scenario Testing**
   - Invalid input handling
   - Database connection failures
   - Timeout scenarios

### Load Testing Parameters
- Virtual users: 1000
- Ramp-up time: 5 minutes
- Test duration: 30 minutes
- Success rate: > 99%

## Monitoring and Alerting

### CloudWatch Metrics

1. **Function Metrics**
   - Invocations
   - Duration
   - Errors
   - Throttles

2. **Business Metrics**
   - Survey completion rate
   - Question response rate
   - Low rating frequency

### Alert Thresholds

| Metric | Warning | Critical |
|--------|---------|----------|
| Error Rate | > 5% | > 10% |
| Duration | > 10s | > 20s |
| Completion Rate | < 80% | < 60% |
| Low Ratings | > 30% | > 50% |

## Deployment Configuration

### SAM Template Parameters
```yaml
Parameters:
  Environment:
    Type: String
    Default: dev
    AllowedValues: [dev, staging, prod]
  
  LogLevel:
    Type: String
    Default: INFO
    AllowedValues: [DEBUG, INFO, WARN, ERROR]
  
  TimeoutSeconds:
    Type: Number
    Default: 30
    MinValue: 5
    MaxValue: 900
```

### Environment-Specific Configuration

#### Development
- Log Level: DEBUG
- DynamoDB: On-demand billing
- Lambda: 128MB memory
- Timeout: 30 seconds

#### Production
- Log Level: WARN
- DynamoDB: On-demand billing
- Lambda: 256MB memory
- Timeout: 30 seconds
- Dead letter queue enabled 