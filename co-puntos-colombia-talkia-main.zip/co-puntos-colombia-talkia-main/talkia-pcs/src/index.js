import { DynamoDBClient } from '@aws-sdk/client-dynamodb';
import { DynamoDBDocumentClient, UpdateCommand, PutCommand, QueryCommand } from '@aws-sdk/lib-dynamodb';

const dynamoClient = new DynamoDBClient({});
const dynamo = DynamoDBDocumentClient.from(dynamoClient);

const PCS_TABLE = process.env.PCS_TABLE;

// Flag to track if questions have been populated
let questionsPopulated = false;

const createResponse = (statusCode, body) => ({
    statusCode,
    body: JSON.stringify(body)
  });
  
function generateNumericMenu() {
    const ratings = [
        {
            id: "1",
            title: "1",
        },
        {
            id: "2",
            title: "2",
        },
        {
            id: "3",
            title: "3",
        },
        {
            id: "4",
            title: "4",
        },
        {
            id: "5",
            title: "5",
        }
    ];

    const whatsappTemplate = {
        templateType: "WhatsAppInteractiveList",
        version: "1.0",
        data: {
            content: {
                title: "Opciones disponibles",
                body: {
                    text: "Seleccione una opción para continuar"
                },
                // footer: {
                //     text: "Seleccione una opción para continuar"
                // },
                action: {
                    button: "Opciones disponibles",
                    sections: [
                        {
                            title: "Opciones disponibles",
                            rows: ratings
                        }
                    ]
                }
            }
        }
    };

    return whatsappTemplate;
}

function generateBinaryMenu() {
    const whatsappTemplate = {
        templateType: "WhatsAppInteractiveReplyButton",
        version: "1.0",
        data: {
            content: {
                title: "Opciones disponibles",
                body: {
                    text: "Seleccione una opción para continuar"
                },
                action: {
                    buttons: [
                        {
                            type: "reply",
                            reply: {
                                id: "SI",
                                title: "Sí"
                            }
                        },
                        {
                            type: "reply",
                            reply: {
                                id: "NO",
                                title: "No"
                            }
                        }
                    ]
                }
            }
        }
    };

    return whatsappTemplate;
}

function generateSurveyConfirmationMenu() {
    const whatsappTemplate = {
        templateType: "WhatsAppInteractiveReplyButton",
        version: "1.0",
        data: {
            content: {
                title: "Confirmación",
                body: {
                    text: "¿Deseas realizar la encuesta?"
                },
                action: {
                    buttons: [
                        {
                            type: "reply",
                            reply: {
                                id: "SI",
                                title: "Sí"
                            }
                        },
                        {
                            type: "reply",
                            reply: {
                                id: "NO",
                                title: "No"
                            }
                        }
                    ]
                }
            }
        }
    };

    return whatsappTemplate;
}

// Add updateSurveyAnswer function
async function updateSurveyAnswer(questionId, answer, sessionId) {
    if (!questionId || !sessionId) return;
    const params = {
        TableName: PCS_TABLE,
        Key: { 
            questionId: questionId,
            sessionId: sessionId
        },
        UpdateExpression: 'SET answer = :answer, updatedAt = :updatedAt',
        ExpressionAttributeValues: {
            ':answer': answer,
            ':updatedAt': new Date().toISOString()
        }
    };
    await dynamo.send(new UpdateCommand(params));
}

// Add method to populate question texts
async function populateQuestionTexts() {
    const questions = [
        {
            questionId: "0",
            questionText: "¿Deseas realizar la encuesta?",
        },
        {
            questionId: "1",
            questionText: "¿Qué tan satisfecho te encuentras con la experiencia que tuviste en el canal de Whatsapp de Puntos Colombia? \n\nSelecciona de 1 a 5 donde 1 es \"Muy insatisfecho\" y 5 es \"Muy satisfecho\".\n\n1 ☹️ Muy insatisfecho\n2 😕 Insatisfecho\n3 😐 Ni satisfecho e insatisfecho\n4 😀 Satisfecho\n5 🤩 Muy satisfecho",
        },
        {
            questionId: "2",
            questionText: "¿Qué tan fácil fue para ti interactuar con Puntos Colombia a través del Whatsapp? \n\nSelecciona de 1 a 5, donde 1 es \"Muy difícil\", y 5 es \"Muy fácil\".\n\n1 ☹️ Muy difícil\n2 😕 Difícil\n3 😐 Neutral\n4 😀 Fácil\n5 🤩 Muy fácil",
        },
        {
            questionId: "3",
            questionText: "¿Recibiste solución a tu solicitud o requerimiento?",
        },
        {
            questionId: "4",
            questionText: "¿Quieres compartirnos algún comentario adicional?\n\nSelecciona:\n\"Sí\" Para dejar tu mensaje.\n\"No\" Para finalizar.",
        },
        {
            questionId: "5",
            questionText: "Escribe por favor tu comentario de forma breve y en un solo mensaje.",
        }
    ];

    for (const question of questions) {
        const params = {
            TableName: PCS_TABLE,
            Item: {
                questionId: question.questionId,
                sessionId: "template", 
                questionText: question.questionText,
                answer: "",
                updatedAt: new Date().toISOString(),

            }
        };
        
        try {
            await dynamo.send(new PutCommand(params));
            console.log(`Populated question: ${question.questionId}`);
        } catch (error) {
            console.error(`Error populating question ${question.questionId}:`, error);
        }
    }
}

// Add a handler to populate questions (can be called via API Gateway or directly)
export const populateQuestions = async (event) => {
    try {
        await populateQuestionTexts();
        return createResponse(200, {
            message: 'Questions populated successfully',
            timestamp: new Date().toISOString()
        });
    } catch (error) {
        console.error('Error populating questions:', error);
        return createResponse(500, {
            error: 'Failed to populate questions',
            message: error.message
        });
    }
};

// Make handlers async and update DynamoDB when slot is set
async function handleNumericOpinion(event, intentName, slots, sessionAttributes) {
    const inputTranscript = event.inputTranscript;
    const validRatings = ['1', '2', '3', '4', '5'];
    const lowRatings = ['1', '2', '3'];
    
    let userInput = null;

    // Check if we already have a valid rating in slots
    const currentRating = slots.numericRating?.value?.interpretedValue;
    if (currentRating && validRatings.includes(currentRating)) {
        userInput = currentRating;
        console.log(`Valid rating found in slots: ${userInput}`);
    }
    
    // If no valid slot value, check interpretations for valid selections
    if (!userInput && event.interpretations && event.interpretations.length > 0) {
        const interpretation = event.interpretations[0];
        if (interpretation.intent && interpretation.intent.slots) {
            for (const [slotName, slotValue] of Object.entries(interpretation.intent.slots)) {
                if (slotValue && slotValue.value && slotValue.value.interpretedValue) {
                    const interpretedValue = slotValue.value.interpretedValue;
                    if (validRatings.includes(interpretedValue)) {
                        userInput = interpretedValue;
                        console.log(`Valid rating from interpretation: ${userInput}`);
                        break;
                    }
                }
            }
        }
    }
    
    // Also check direct input transcript for valid document types
    if (!userInput && inputTranscript && validRatings.includes(inputTranscript)) {
        userInput = inputTranscript;
        console.log(`Valid rating from input transcript: ${userInput}`);
    }

    // If we have a valid document type selection, fulfill the intent
    if (userInput && validRatings.includes(userInput)) {
        console.log(`Fulfilling NumericOpinion intent with: ${userInput}`);
        
        // Check if the response is a low rating and set session attribute
        if (lowRatings.includes(userInput)) {
            sessionAttributes.flag = "true";
            console.log('Setting session attribute flagged to true for low rating');
        }
        // Update DynamoDB with answer
        const questionId = sessionAttributes.questionId;
        const sessionId = sessionAttributes.sessionId || event.sessionId || 'default-session';
        await updateSurveyAnswer(questionId, userInput, sessionId);
        return {
            sessionState: {
                dialogAction: {
                    type: "Close"
                },
                intent: {
                    name: intentName,
                    state: "Fulfilled",
                    slots: {
                        numericRating: {
                            value: {
                                interpretedValue: userInput,
                                originalValue: userInput,
                                resolvedValues: [userInput]
                            }
                        }
                    }
                },
                sessionAttributes: sessionAttributes
            }
        };
    }

    // If no valid document type selected, show the menu
    console.log('No valid rating selection detected, showing numeric menu');
    const menuTemplate = generateNumericMenu();
    
    console.log('Generated numeric menu template:', JSON.stringify(menuTemplate, null, 2));
    
    return {
        sessionState: {
            dialogAction: {
                type: "ElicitSlot",
                slotToElicit: "numericRating"
            },
            intent: {
                name: intentName,
                state: "InProgress",
                slots: slots
            },
            sessionAttributes: sessionAttributes
        },
        messages: [
            {
                contentType: "CustomPayload",
                content: JSON.stringify(menuTemplate)
            }
        ]
    };
}

async function handleBinaryOpinion(event, intentName, slots, sessionAttributes) {
    const inputTranscript = event.inputTranscript;
    const validRatings = ['SI', 'NO','Sí','No','si','no','Si','sí'];
    const negativeResponses = ['NO', 'No', 'no'];
    let userInput = null;
    
    // Check if we already have a valid confirmation in slots
    const currentRating = slots.binaryRating?.value?.interpretedValue;
    if (currentRating && validRatings.includes(currentRating)) {
        userInput = currentRating;
        console.log(`Valid rating found in slots: ${userInput}`);
    }
    
    // If no valid slot value, check interpretations for valid selections
    if (!userInput && event.interpretations && event.interpretations.length > 0) {
        const interpretation = event.interpretations[0];
        if (interpretation.intent && interpretation.intent.slots) {
            for (const [slotName, slotValue] of Object.entries(interpretation.intent.slots)) {
                if (slotValue && slotValue.value && slotValue.value.interpretedValue) {
                    const interpretedValue = slotValue.value.interpretedValue;
                    if (validRatings.includes(interpretedValue)) {
                        userInput = interpretedValue;
                        console.log(`Valid rating from interpretation: ${userInput}`);
                        break;
                    }
                }
            }
        }
    }
    
    // Also check direct input transcript for valid confirmations
    if (!userInput && inputTranscript && validRatings.includes(inputTranscript)) {
        userInput = inputTranscript;
        console.log(`Valid rating from input transcript: ${userInput}`);
    }

    // If we have a valid confirmation selection, fulfill the intent
    if (userInput && validRatings.includes(userInput)) {
        console.log(`Fulfilling BinaryOpinion intent with: ${userInput}`);
        
        // Check if the response is negative and set session attribute
        if (negativeResponses.includes(userInput)) {
            sessionAttributes.flag = "true";
            console.log('Setting session attribute flagged to true');
        }
        // Update DynamoDB with answer
        const questionId = sessionAttributes.questionId;
        const sessionId = sessionAttributes.sessionId || event.sessionId || 'default-session';
        await updateSurveyAnswer(questionId, userInput, sessionId);
        return {
            sessionState: {
                dialogAction: {
                    type: "Close"
                },
                intent: {
                    name: intentName,
                    state: "Fulfilled",
                    slots: {
                        binaryRating: {
                            value: {
                                interpretedValue: userInput,
                                originalValue: userInput,
                                resolvedValues: [userInput]
                            }
                        }
                    }
                },
                sessionAttributes: sessionAttributes
            }
        };
    }

    // If no valid confirmation selected, show the menu
    console.log('No valid rating selection detected, showing binary menu');
    const menuTemplate = generateBinaryMenu();
    
    console.log('Generated binary menu template:', JSON.stringify(menuTemplate, null, 2));
    
    return {
        sessionState: {
            dialogAction: {
                type: "ElicitSlot",
                slotToElicit: "binaryRating"
            },
            intent: {
                name: intentName,
                state: "InProgress",
                slots: slots
            },
            sessionAttributes: sessionAttributes
        },
        messages: [
            {
                contentType: "CustomPayload",
                content: JSON.stringify(menuTemplate)
            }
        ]
    };
}

async function handleSurveyAccept(event, intentName, slots, sessionAttributes) {
    const inputTranscript = event.inputTranscript;    
    const validConfirmations = ['SI', 'NO','Sí','No','si','no'];
    
    let userInput = null;
    
    // Check if we already have a valid confirmation in slots
    const currentConfirmation = slots.surveyConfirmation?.value?.interpretedValue;
    if (currentConfirmation && validConfirmations.includes(currentConfirmation)) {
        userInput = currentConfirmation;
        console.log(`Valid confirmation found in slots: ${userInput}`);
    }
    
    // If no valid slot value, check interpretations for valid selections
    if (!userInput && event.interpretations && event.interpretations.length > 0) {
        const interpretation = event.interpretations[0];
        if (interpretation.intent && interpretation.intent.slots) {
            for (const [slotName, slotValue] of Object.entries(interpretation.intent.slots)) {
                if (slotValue && slotValue.value && slotValue.value.interpretedValue) {
                    const interpretedValue = slotValue.value.interpretedValue;
                    if (validConfirmations.includes(interpretedValue)) {
                        userInput = interpretedValue;
                        console.log(`Valid confirmation from interpretation: ${userInput}`);
                        break;
                    }
                }
            }
        }
    }
    
    // Also check direct input transcript for valid confirmations
    if (!userInput && inputTranscript && validConfirmations.includes(inputTranscript)) {
        userInput = inputTranscript;
        console.log(`Valid confirmation from input transcript: ${userInput}`);
    }

    // If we have a valid confirmation selection, fulfill the intent
    if (userInput && validConfirmations.includes(userInput)) {
        console.log(`Fulfilling DocumentConfirmation intent with: ${userInput}`);
        const questionId = sessionAttributes.questionId;
        const sessionId = sessionAttributes.sessionId || event.sessionId || 'default-session';
        await updateSurveyAnswer(questionId, userInput, sessionId);
        return {
            sessionState: {
                dialogAction: {
                    type: "Close"
                },
                intent: {
                    name: intentName,
                    state: "Fulfilled",
                    slots: {
                        surveyConfirmation: {
                            value: {
                                interpretedValue: userInput,
                                originalValue: userInput,
                                resolvedValues: [userInput]
                            }
                        }
                    }
                },
                sessionAttributes: sessionAttributes
            }
        };
    }

    // If no valid confirmation selected, show the menu
    console.log('No valid confirmation selection detected, showing confirmation menu');
    const menuTemplate = generateSurveyConfirmationMenu();
    
    console.log('Generated confirmation menu template:', JSON.stringify(menuTemplate, null, 2));
    
    return {
        sessionState: {
            dialogAction: {
                type: "ElicitSlot",
                slotToElicit: "surveyConfirmation"
            },
            intent: {
                name: intentName,
                state: "InProgress",
                slots: slots
            },
            sessionAttributes: sessionAttributes
        },
        messages: [
            {
                contentType: "CustomPayload",
                content: JSON.stringify(menuTemplate)
            }
        ]
    };
}

async function handleClientComplaint(event, intentName, slots, sessionAttributes) {
    const inputTranscript = event.inputTranscript;
    let userQuery = null;
            
    if (inputTranscript && inputTranscript.trim().length > 0) {
        const triggerPhrases = ['COMPLAINT', intentName];
        
        if (!triggerPhrases.includes(inputTranscript.toUpperCase())) {
            userQuery = inputTranscript.trim();
            console.log(`User query captured: "${userQuery}"`);
        }
    }

    // If we have a valid user query, process it
    if (userQuery) {
        // Update DynamoDB with answer
        const questionId = sessionAttributes.questionId;
        const sessionId = sessionAttributes.sessionId || event.sessionId || 'default-session';
        await updateSurveyAnswer(questionId, userQuery, sessionId);
        // Fulfill the intent with the query slot filled
        return {
            sessionState: {
                dialogAction: {
                    type: "Close"
                },
                intent: {
                    name: intentName,
                    state: "Fulfilled",
                    slots: {
                        complaint: {
                            value: {
                                interpretedValue: userQuery,
                                originalValue: userQuery,
                                resolvedValues: [userQuery]
                            }
                        }
                    }
                },
                sessionAttributes: sessionAttributes
            }
        };
    }

    // If no valid query yet, prompt for it
    console.log('No valid query detected, prompting user');

    return {
        sessionState: {
            dialogAction: {
                type: "ElicitSlot",
                slotToElicit: "complaint"
            },
            intent: {
                name: intentName,
                state: "InProgress",
                slots: slots
            },
            sessionAttributes: sessionAttributes
        },
        messages: [
            {
                contentType: "PlainText",
                content: "Escribe por favor tu comentario de forma breve y en un solo mensaje."
            }
        ]
    };
}

export const surveyHook = async (event) => {
    try {
        console.log('Received event:', JSON.stringify(event, null, 2));

        // Populate questions once when the function is first triggered
        if (!questionsPopulated) {
            console.log('First time running surveyHook, populating questions...');
            await populateQuestionTexts();
            questionsPopulated = true;
            console.log('Questions populated successfully');
        }

        if (event.sessionState && event.sessionState.intent) {
            const intentName = event.sessionState.intent.name;
            const invocationSource = event.invocationSource;
            const inputTranscript = event.inputTranscript;
            const slots = event.sessionState.intent.slots || {};
            const sessionAttributes = event.sessionState.sessionAttributes || {};

            console.log(`Intent: ${intentName}, Invocation: ${invocationSource}, Input: ${inputTranscript}`);

            // Handle different intents
            if (intentName === "NumericOpinion") {
                return await handleNumericOpinion(event, intentName, slots, sessionAttributes);
            } else if (intentName === "BinaryOpinion") {
                return await handleBinaryOpinion(event, intentName, slots, sessionAttributes);
            } else if (intentName === "SurveyAccept") {
                return await handleSurveyAccept(event, intentName, slots, sessionAttributes);
            } else if (intentName === "ClientComplaint") {
                return await handleClientComplaint(event, intentName, slots, sessionAttributes);
            } else {
                console.log(`Unhandled intent: ${intentName}`);
                return createResponse(400, {
                    error: `Unhandled intent: ${intentName}`
                });
            }
        }

    } catch (error) {
        console.error('Error in documentHook:', error);
        
        return createResponse(500, {
            error: 'Internal server error',
            message: 'Failed to process hook'
        });
    }
};

export const updateAnswer = async (event) => {
    try {
        console.log('Received updateAnswer event:', JSON.stringify(event, null, 2));

        const { questionId, answer, contactId } = event.Details.Parameters;

        // Validate required parameters
        if (!questionId || !answer || !contactId) {
            console.error('Missing required parameters: questionId, answer, or contactId');
            return createResponse(400, {
                error: 'Missing required parameters',
                required: ['questionId', 'answer', 'contactId'],
                received: { questionId, answer, contactId }
            });
        }

        // Update DynamoDB with the answer
        await updateSurveyAnswer(questionId, answer, contactId);

        console.log(`Successfully updated answer for questionId: ${questionId}, contactId: ${contactId}`);

        return createResponse(200, {
            message: 'Answer updated successfully',
            questionId: questionId,
            contactId: contactId,
            answer: answer,
            timestamp: new Date().toISOString()
        });

    } catch (error) {
        console.error('Error in updateAnswer:', error);
        
        return createResponse(500, {
            error: 'Internal server error',
            message: 'Failed to update answer',
            details: error.message
        });
    }
};